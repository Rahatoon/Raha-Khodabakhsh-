// Zelfuitvoerende functie met behulp van jQuery
(function ($) {

    // jQuery-methode om te controleren of een element bestaat
    $.fn.exists = function () {
        return this.length !== 0;
    }

    // Functie om te controleren of het apparaat een iPhone of iPod is
    function isiPhone() {
        return (
            (navigator.platform.indexOf("iPhone") !== -1) || (navigator.platform.indexOf("iPod") !== -1)
        );
    }

    // Variabelen
    var $document = $(document);
    var $window = $(window);
    var $body = $('body');
    var $nav = $('header nav');
    var $hero = $('.hero');
    
    // Bereken 80% van de hero-hoogte
    var heroHeightPerc = $hero.height() * 0.8; // Als 80% van de hero is gescrold
    var z_portfolio_item_open = false;

    // Functie om de kleur van de header-navigatie te wijzigen op basis van scrollpositie
    function scrollChangeHeaderNav() {
        var navOffsetTop = $nav.offset().top;

        // Als de scrollpositie meer is dan 80% van de hero-hoogte
        if (navOffsetTop > heroHeightPerc) {
            $body.addClass('has-default-nav');
        } else {
            $body.removeClass('has-default-nav');
        }
    }

    // Luister naar scrollgebeurtenissen om de header-navigatie bij te werken
    window.addEventListener('scroll', function () {
        scrollChangeHeaderNav();
    });

    // Ajax-oproep om een willekeurig logo op te halen en in te voegen in de header
    $.ajax({
        url: 'https://zodan.nl/branding/logo/random.php?c=1&w=130',
        dataType: 'text',
        type: 'GET',
        async: true,
        statusCode: {
            // Als de statuscode 404 is (niet gevonden)
            404: function (response) {
                console.log('404 - fout bij het ophalen van het willekeurige logo');
                // Plaats het standaardlogo in de header
                $('#header .logo').html('<img src="https://zodan.nl/wp/wp-content/themes/zodan_v6/img/logo-white.svg" alt="zodan logo" title="Zodan" />');
            },
            // Als de statuscode 200 is (succesvol)
            200: function (response) {
                // Plaats het opgehaalde logo in de header
                $('#header .logo').html(response);
            }
        },
        error: function (jqXHR, status, errorThrown) {
            // Log eventuele fouten in de console
            // console.log(status + ':' + errorThrown);
            // $('#header .logo').html('<span>Zodan</span>');
        }
    });

    // Initialisatie van het menu-overlay
    $('#btn-open-menu').click(function (e) {
        e.preventDefault();
        // Voeg animatieklasse toe aan het menu
        $('.app-menu').addClass('menu--animatable');
        // Maak het hoofdmenu zichtbaar voor schermlezers
        $('.main-menu-box').attr('aria-hidden', 'false');
    });

    // Sluit het menu
    $('.close-menu').click(function () {
        // Verberg het hoofdmenu voor schermlezers
        $('.main-menu-box').attr('aria-hidden', 'true');
        // Verwijder de mogelijkheid om te scrollen op body
        $('body').removeClass('noscroll');
    });

    // Verwijder animatieklasse na overgang van het menu
    function menuOnTransitionEnd() {
        $('.app-menu').removeClass('menu--animatable');
    }
    // Voeg overgangsgebeurtenis toe aan het menu
    $('.app-menu').on('transitionend', menuOnTransitionEnd);

    // Initialisatie van het zoek-overlay
    $('.search-btn').click(function (e) {
        e.preventDefault();
        // Voeg animatieklasse toe aan het zoek-overlay
        $('.top-search-area').addClass('menu--animatable');
        // Maak het zoekformulier zichtbaar voor schermlezers
        $('.top-search-form-bar').attr('aria-hidden', 'false');
        // Plaats de focus op het zoekveld
        $('#global-search').focus();
    });

    // Sluit het zoek-overlay
    $('.close-search').click(function () {
        // Verberg het zoekformulier voor schermlezers
        $('.top-search-form-bar').attr('aria-hidden', 'true');
        // Verwijder de mogelijkheid om te scrollen op body
        $('body').removeClass('noscroll');
    });

    // Verwijder animatieklasse na overgang van het zoek-overlay
    function searchOnTransitionEnd() {
        $('.top-search-area').removeClass('menu--animatable');
    }
    // Voeg overgangsgebeurtenis toe aan het zoek-overlay
    $('.top-search-area').on('transitionend', searchOnTransitionEnd);

    // Initialisatie van het klikdan-overlay
    $('.klikdan-btn').click(function (e) {
        e.preventDefault();
        // Voeg animatieklasse toe aan het klikdan-overlay
        $('.klikdan-menu').addClass('menu--animatable');
        // Maak het klikdan-box zichtbaar voor schermlezers
        $('.klikdan-box').attr('aria-hidden', 'false');
        // Voeg klasse toe om scrollen op body te voorkomen
        // $('body').addClass('noscroll');
    });

    // Sluit het klikdan-overlay
    $('.close-klikdan').click(function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        // Forceer een klik op mini_play en .ieniemienie
        $('#mini_play, .ieniemienie').trigger('click');
        // Vertraag het verbergen van het klikdan-box
        setTimeout(function () {
            $('.klikdan-box').attr('aria-hidden', 'true');
            // Verwijder de mogelijkheid om te scrollen op body
            $('body').removeClass('noscroll');
        }, 1600);
    });

    // Verwijder animatieklasse na overgang van het klikdan-overlay
    function klikdanOnTransitionEnd() {
        $('.klikdan-menu').removeClass('menu--animatable');
    }
    // Voeg overgangsgebeurtenis toe aan het klikdan-overlay
    $('.klikdan-menu').on('transitionend', klikdanOnTransitionEnd);

    // Vereenvoudigde versie van JS-video-besturingselementen voor Zodan Quote-video
    var zvideo;
    var playBaseClass;
    var playbutton_url = "https://zodan.nl/wp/wp-content/themes/zodan_v6/img/z-tv-button.webp";
    var pausebutton_url = "https://zodan.nl/wp/wp-content/themes/zodan_v6/img/z-tv-button-pause.webp";
    var vholder = document.getElementById('z-tv-holder');
    var btnPlay;

    // Initialisatie van de Z-video
    initZVideoPlayer();

    function initZVideoPlayer() {
        // Controleer of het element met id 'z-video' bestaat
        if (zvideo = document.getElementById('z-video')) {
            playVid();
        }
    }

    function playVid() {
        // Zoek het afspeelknop-element
        btnPlay = document.getElementById('btnZplay');
        playBaseClass = btnPlay.className;
        var t; // Timer

        // Functie om de timer te starten
        function startCount() {
            t = window.setInterval(function () {
                if (zvideo.ended !== true) {
                } else {
                    // Wanneer de video eindigt, wijzig de knop naar 'Play'
                    btnPlay.firstChild.nodeValue = 'Play';
                    // Verwijder de afspeelklasse en vervang de afbeelding
                    btnPlay.setAttribute("class", playBaseClass + " paused");
                    $('.z-video-play-button img').attr('src', playbutton_url);
                    // Stop de timer
                    window.clearInterval(t);
                }
            }, 1000);
        }

        // Functie om de timer te stoppen
        function pauseCount() {
            window.clearInterval(t);
        }

        // Voeg een klikgebeurtenis toe aan de Z-video en vholder
        zvideo.addEventListener('click', playControl, false);
        vholder.addEventListener('click', playControl, false);

        // Functie voor afspelen/pauzeren van de video
        function playControl() {
            if (zvideo.paused === false) {
                // Pauzeer de video
                zvideo.pause();
                // Wijzig de knop naar 'Play'
                btnPlay.firstChild.nodeValue = 'Play';
                // Verwijder de afspeelklasse en vervang de afbeelding
                btnPlay.setAttribute("class", playBaseClass + " paused");
                $('.z-video-play-button img').attr('src', playbutton_url);
                // Stop de timer
                pauseCount();
            } else {
                // Start de video
                zvideo.play();
                // Wijzig de knop naar 'Pause'
                btnPlay.firstChild.nodeValue = 'Pause';
                // Voeg de afspeelklasse toe en vervang de afbeelding
                btnPlay.setAttribute("class", playBaseClass + " playing");
                $('.z-video-play-button img').attr('src', pausebutton_url);
                // Start de timer
                startCount();
            }
        }
    }

    // Vereenvoudigde versie van JS-video-besturingselementen voor Zodan ieniemienie-video
    var ieniemienie_vid;

    // Functie om de mini-speler te starten
    function startMiniPlayer() {
        // Controleer of het element met id 'z-video-ieniemienie' bestaat
        if (ieniemienie_vid = document.getElementById('z-video-ieniemienie')) {
            // Als het een iPhone is, vervang de video door een geanimeerde gif
            if (isiPhone()) {
                // Verwijder het video-element
                ieniemienie_vid.parentNode.removeChild(ieniemienie_vid);
                // Voeg klassen toe om de geanimeerde gif weer te geven
                $('#z-img-ieniemienie').addClass('active off');
                // Voeg een klikgebeurtenis toe aan .ieniemienie
                $('.ieniemienie').click(function () {
                    // Toon de geanimeerde gif
                    $('#z-img-ieniemienie').removeClass('off');
                    // Speel een geluid af
                    var ieniemienieSound = document.getElementById('ieniemienieSound');
                    ieniemienieSound.volume = 1;
                    ieniemienieSound.play();
                    // Wanneer het geluid eindigt, verberg de geanimeerde gif
                    ieniemienieSound.onended = function () {
                        $('#z-img-ieniemienie').addClass('off');
                    };
                });
            } else {
                // Bereid de mini-video voor
                prepareMiniVid();
            }
        }
    }

    // Functie om de mini-video voor te bereiden
    function prepareMiniVid() {
        // Voeg een klikgebeurtenis toe aan mini_play en ieniemienie_vid
        var miniPlay = document.getElementById('mini_play');
        miniPlay.addEventListener('click', playMiniControl, false);
        ieniemienie_vid.addEventListener('click', playMiniControl, false);
    }

    // Functie voor afspelen van de mini-video
    function playMiniControl() {
        ieniemienie_vid.play();
    }

    // Voer de functie uit voor het starten van de mini-speler bij het laden van de pagina
    window.onload = startMiniPlayer;

})(jQuery);
